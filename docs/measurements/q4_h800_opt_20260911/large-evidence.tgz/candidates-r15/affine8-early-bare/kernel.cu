// Development-only CUDA instructions for canonical Q4 K-pack words.
// No offline permutation, FP16 dot accumulation or expanded scale plane.
#pragma once
#include <cuda_fp16.h>
#include <cuda_runtime.h>
#include <cstdint>

namespace quactlize::dev::q4_native {

struct ScaleZero {
    __half scale;
    __half zero;
};

__device__ __forceinline__ uint4 load_unit(uint8_t const* p) {
    if ((uintptr_t(p) & 15) == 0) return *reinterpret_cast<uint4 const*>(p);
    // Packed-unit pointers have no public 16-byte alignment requirement.
    uint32_t w[4];
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        w[i] = uint32_t(p[4*i]) | (uint32_t(p[4*i+1]) << 8) |
               (uint32_t(p[4*i+2]) << 16) | (uint32_t(p[4*i+3]) << 24);
    }
    return make_uint4(w[0], w[1], w[2], w[3]);
}

__device__ __forceinline__ ScaleZero scale_zero(uint4 const m, unsigned group) {
    uint64_t const run = (group & 4)
        ? uint64_t(m.z >> 16) | (uint64_t(m.w) << 16)
        : uint64_t(m.y) | (uint64_t(m.z & 0xffff) << 32);
    unsigned const shift = 6 * (group & 3);
    unsigned const sc = unsigned(run >> shift) & 63;
    unsigned const mn = unsigned(run >> (24 + shift)) & 63;
    __half const scale = __hmul(__ushort_as_half(uint16_t(m.x)), __int2half_rn(sc));
    __half const zero = __hneg(__hmul(__ushort_as_half(uint16_t(m.x >> 16)),
                                    __int2half_rn(mn)));
    // Preserve unit_group<Q4_K,8>: round each metadata product to half,
    // then one FP32 expression and one half rounding for the +8 correction.
    return {scale, zero};
}

template<int Slot>
__device__ __forceinline__ __half2 codes(uint32_t words) {
    static_assert(Slot >= 0 && Slot < 4);
    // The two b16 halves own adjacent N columns, not adjacent K values.
    uint32_t const bits = ((words >> (4 * Slot)) & 0x000f000fu) | 0x64006400u;
    __half2_raw raw;
    raw.x = uint16_t(bits);
    raw.y = uint16_t(bits >> 16);
    return __hsub2(__half2(raw), __float2half2_rn(1024.f));
}

__device__ __forceinline__ float4 activation(void const* base, int64_t offset,
                                            int input_type) {
    if (input_type == 0) {
        auto p = static_cast<__half const*>(base) + offset;
        if ((uintptr_t(p) & 3) == 0) {
            float2 const lo = __half22float2(*reinterpret_cast<__half2 const*>(p));
            float2 const hi = __half22float2(*reinterpret_cast<__half2 const*>(p + 2));
            return make_float4(lo.x, lo.y, hi.x, hi.y);
        }
        return make_float4(__half2float(p[0]), __half2float(p[1]),
                           __half2float(p[2]), __half2float(p[3]));
    }
    auto p = static_cast<float const*>(base) + offset;
    float4 v;
    if ((uintptr_t(p) & 15) == 0) v = *reinterpret_cast<float4 const*>(p);
    else v = make_float4(p[0], p[1], p[2], p[3]);
    // F32 endpoints still cross the same FP16-A boundary as the N2 reader.
    v.x = __half2float(__float2half_rn(v.x));
    v.y = __half2float(__float2half_rn(v.y));
    v.z = __half2float(__float2half_rn(v.z));
    v.w = __half2float(__float2half_rn(v.w));
    return v;
}

template<int Slot>
__device__ __forceinline__ void dot_slot(void const* a_base, int64_t group_offset,
    int input_type, uint32_t const (&words)[8], __half2 scale, __half2 zero,
    float (&x)[4], float (&y)[4]) {
    #pragma unroll
    for (int first = 0; first < 8; first += 4) {
        float4 const a = activation(a_base, group_offset + 8*Slot + first, input_type);
        float const av[4] = {a.x, a.y, a.z, a.w};
        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            float2 const w = __half22float2(__hfma2(codes<Slot>(words[first+i]), scale, zero));
            x[i] = fmaf(av[i], w.x, x[i]);
            y[i] = fmaf(av[i], w.y, y[i]);
        }
    }
}

} // namespace quactlize::dev::q4_native

#pragma once


namespace quactlize::dev::q4_native {
__device__ __forceinline__ ScaleZero aligned_scale_zero(uint4 m,unsigned group) {
    uint64_t const run=(group&4) ? uint64_t(m.z>>16)|(uint64_t(m.w)<<16)
                                : uint64_t(m.y)|(uint64_t(m.z&0xffff)<<32);
    unsigned const shift=6*(group&3);
    unsigned const sc=unsigned(run>>shift)&63, mn=unsigned(run>>(24+shift))&63;
    __half2_raw codes_raw,header_raw;
    codes_raw.x=uint16_t(0x6400|sc);codes_raw.y=uint16_t(0x6400|mn);
    header_raw.x=uint16_t(m.x);header_raw.y=uint16_t(m.x>>16);
    __half2 const products=__hmul2(__hsub2(__half2(codes_raw),__float2half2_rn(1024.f)),__half2(header_raw));
    __half const scale=__low2half(products),zero=__hneg(__high2half(products));
    return {scale,zero};
}
__device__ __forceinline__ uint4 aligned_unit(uint8_t const* p) {
    return *reinterpret_cast<uint4 const*>(p);
}
__device__ __forceinline__ uint32_t aligned_word(uint16_t const* p) {
    return *reinterpret_cast<uint32_t const*>(p);
}
template<int Type>
__device__ __forceinline__ float4 aligned_activation(void const* base,int64_t offset) {
    if constexpr (Type==0) {
        auto p=static_cast<__half const*>(base)+offset;
        float2 const a=__half22float2(*reinterpret_cast<__half2 const*>(p));
        float2 const b=__half22float2(*reinterpret_cast<__half2 const*>(p+2));
        return make_float4(a.x,a.y,b.x,b.y);
    } else {
        float4 v=*reinterpret_cast<float4 const*>(static_cast<float const*>(base)+offset);
        v.x=__half2float(__float2half_rn(v.x)); v.y=__half2float(__float2half_rn(v.y));
        v.z=__half2float(__float2half_rn(v.z)); v.w=__half2float(__float2half_rn(v.w));
        return v;
    }
}
template<int Slot,int Type>
__device__ __forceinline__ void aligned_dot_slot(void const* a,int64_t group_offset,
    uint32_t const (&words)[8],__half2 scale,__half2 zero,float (&x)[4],float (&y)[4]) {
    #pragma unroll
    for (int first=0;first<8;first+=4) {
        float4 const v=aligned_activation<Type>(a,group_offset+8*Slot+first);
        float const av[4]={v.x,v.y,v.z,v.w};
        #pragma unroll
        for (int i=0;i<4;++i) {
            float2 const w=__half22float2(__hfma2(codes<Slot>(words[first+i]),scale,zero));
            x[i]=fmaf(av[i],w.x,x[i]);y[i]=fmaf(av[i],w.y,y[i]);
        }
    }
}
} // namespace quactlize::dev::q4_native

#include "/root/autodl-tmp/q4-ppu-replay.qC6s95/src/dev/gemv_cuda/q4_warp_reduce_scatter.cuh"


#include <hggc_runtime.h>
#include "api.h"
#include "reader.hpp"

#define QKG_CONCAT_IMPL(A,B) A##B
#define QKG_CONCAT(A,B) QKG_CONCAT_IMPL(A,B)
// Each format is a separate translation unit. Explicit namespaces prevent
// same-source host stubs/device registrations from aliasing across objects.
namespace QKG_CONCAT(kpack_q,QKG_QTYPE) {
using namespace quactlize::execution;
#if QKG_QTYPE == 8
using R = Q8Reader;
#else
constexpr KType type = KType(QKG_QTYPE - 10);
using R = Reader<type>;
#endif

__device__ int expert_for(qkg_call_v1 const& c, int row) {
    if (c.mode == QKG_DENSE) return 0;
    if (c.mode == QKG_INDEXED) return c.ids[int64_t(row / c.topk) * c.ids_stride + row % c.topk];
    int lo = 0, hi = c.experts;
    while (lo < hi) {
        int const mid = lo + (hi - lo) / 2;
        if (c.offsets[mid + 1] <= row) lo = mid + 1;
        else hi = mid;
    }
    return lo;
}

// The pair reader keeps one b16 word from each plane live across all K8
// slots in this metadata group. It uses half2 only for exact code conversion
// and fused affine dequantization; the dot still accumulates in FP32.
// Pair two adjacent output columns in each thread. Their canonical b16 words
// are adjacent, so a b32 load and half2 affine serve both dots. A is shared
// between the columns without changing its FP16 conversion boundary.
__device__ __forceinline__ uint32_t n2_word(uint16_t const* ptr) {
    // The public ABI promises b16, not b32, alignment. Do not narrow it for
    // the vector fast path; suballocated planes may begin at base+2 bytes.
    if ((uintptr_t(ptr)&3)==0) return *reinterpret_cast<uint32_t const*>(ptr);
    return uint32_t(ptr[0])|(uint32_t(ptr[1])<<16);
}

template<class Reader>
__device__ __forceinline__ float2 generic_n2_pair_dot(qkg_call_v1 const& c, int64_t a_base,
    uint16_t const* low, uint16_t const* high, uint8_t const* units,
    int col, int worker, int workers, int partition, int split) {
    using R=Reader;
    float x[4]{},y[4]{};
    for (int g=partition*workers+worker; g<c.k/R::group; g+=split*workers) {
        auto const s0=R::scale(units,col,g,c.n),s1=R::scale(units,col+1,g,c.n);
        __half2 const scale=__halves2half2(__ushort_as_half(s0.scale.raw()),__ushort_as_half(s1.scale.raw()));
        __half2 const zero=__halves2half2(__ushort_as_half(s0.zero.raw()),__ushort_as_half(s1.zero.raw()));
        constexpr float bias=R::lo_bits==8 ? 1152.f : R::lo_bits==4 ? 1032.f : 1024.f;
        __half2 const offset=__float2half2_rn(bias);
        uint32_t words[8],high_words[8]{};
        #pragma unroll
        for (int r=0;r<8;++r) {
            int const kk=g*R::group+r;
            words[r]=n2_word(low+R::LowMap::word_index(col,kk,c.n));
            if constexpr (R::hi_bits!=0) {
                // Q5 exchanges N bit 3 with K bits, but keeps N bit 0.
                // Thus even/odd N are adjacent words, not a duplicated word.
                high_words[r]=n2_word(high+R::HighMap::word_index(col,kk,c.n));
            }
        }
        #pragma unroll
        for (int slot=0;slot<R::group/8;++slot) {
            #pragma unroll
            for (int first=0;first<8;first+=4) {
                int const kk=g*R::group+8*slot+first;
                float av[4];
                auto const p=static_cast<float const*>(c.a)+a_base+kk;
                if (c.input_type==QKG_F32 && (uintptr_t(p)&15)==0) {
                    float4 const a=*reinterpret_cast<float4 const*>(p);
                    av[0]=a.x; av[1]=a.y; av[2]=a.z; av[3]=a.w;
                } else {
                    #pragma unroll
                    for (int i=0;i<4;++i)
                        av[i]=c.input_type==QKG_F32 ? p[i]
                            : float(static_cast<Half const*>(c.a)[a_base+kk+i]);
                }
                #pragma unroll
                for (int i=0;i<4;++i) {
                    uint32_t lo=words[first+i],hi=high_words[first+i];
                    if constexpr (R::lo_bits==8)
                        lo=n2_word(low+R::LowMap::word_index(col,kk+i,c.n));
                    int const c0=R::raw_from_words(uint16_t(lo),uint16_t(hi),col,kk+i);
                    int const c1=R::raw_from_words(uint16_t(lo>>16),uint16_t(hi>>16),col+1,kk+i);
                    __half2 codes=__halves2half2(__ushort_as_half(0x6400|c0),__ushort_as_half(0x6400|c1));
                    codes=__hsub2(codes,offset);
                    __half2 weight;
                    if constexpr (R::lo_bits==8) weight=__hmul2(codes,scale);
                    else weight=__hfma2(codes,scale,zero);
                    float2 const w=__half22float2(weight);
                    float const a=__half2float(__float2half_rn(av[i]));
                    x[i]=fmaf(a,w.x,x[i]); y[i]=fmaf(a,w.y,y[i]);
                }
            }
        }
    }
    return make_float2((x[0]+x[1])+(x[2]+x[3]),(y[0]+y[1])+(y[2]+y[3]));
}

// Q4-specific instructions, but identical N2 group ownership and FP32 dot order.
// Other formats keep the generic N2 implementation in this development DSO.
template<class Reader,int Type>
__device__ __forceinline__ float2 aligned_q4_pair_dot(qkg_call_v1 const& c, int64_t a_base,
    uint16_t const* low, uint16_t const* high, uint8_t const* units,
    int col, int worker, int workers, int partition, int split) {
#if QKG_QTYPE != 12
    return generic_n2_pair_dot<Reader>(c, a_base, low, high, units,
                                      col, worker, workers, partition, split);
#else
    using R = Reader;
    using namespace quactlize::dev::q4_native;
    static_assert(R::lo_bits == 4 && R::hi_bits == 0 && R::group == 32);
    float x[4]{}, y[4]{};
    for (int g = partition*workers + worker; g < c.k/32; g += split*workers) {
        auto const p = units + (int64_t(g/8)*c.n + col)*16;
        auto const s0 = aligned_scale_zero(aligned_unit(p), unsigned(g & 7));
        auto const s1 = aligned_scale_zero(aligned_unit(p + 16), unsigned(g & 7));
        __half2 const scale = __halves2half2(s0.scale, s1.scale);
        __half2 const zero = __halves2half2(s0.zero, s1.zero);
        uint32_t words[8];
        #pragma unroll
        for (int r = 0; r < 8; ++r)
            words[r] = aligned_word(low + R::LowMap::word_index(col, g*32+r, c.n));
        // Constant slots keep paired-nibble extraction as a word operation.
        aligned_dot_slot<0,Type>(c.a, a_base + g*32, words, scale, zero, x, y);
        aligned_dot_slot<1,Type>(c.a, a_base + g*32, words, scale, zero, x, y);
        aligned_dot_slot<2,Type>(c.a, a_base + g*32, words, scale, zero, x, y);
        aligned_dot_slot<3,Type>(c.a, a_base + g*32, words, scale, zero, x, y);
    }
    return make_float2((x[0]+x[1])+(x[2]+x[3]), (y[0]+y[1])+(y[2]+y[3]));
#endif
}
// Q4-specific instructions, but identical N2 group ownership and FP32 dot order.
// Other formats keep the generic N2 implementation in this development DSO.
template<class Reader>
__device__ __forceinline__ float2 fallback_q4_pair_dot(qkg_call_v1 const& c, int64_t a_base,
    uint16_t const* low, uint16_t const* high, uint8_t const* units,
    int col, int worker, int workers, int partition, int split) {
#if QKG_QTYPE != 12
    return generic_n2_pair_dot<Reader>(c, a_base, low, high, units,
                                      col, worker, workers, partition, split);
#else
    using R = Reader;
    using namespace quactlize::dev::q4_native;
    static_assert(R::lo_bits == 4 && R::hi_bits == 0 && R::group == 32);
    float x[4]{}, y[4]{};
    for (int g = partition*workers + worker; g < c.k/32; g += split*workers) {
        auto const p = units + (int64_t(g/8)*c.n + col)*16;
        auto const s0 = scale_zero(load_unit(p), unsigned(g & 7));
        auto const s1 = scale_zero(load_unit(p + 16), unsigned(g & 7));
        __half2 const scale = __halves2half2(s0.scale, s1.scale);
        __half2 const zero = __halves2half2(s0.zero, s1.zero);
        uint32_t words[8];
        #pragma unroll
        for (int r = 0; r < 8; ++r)
            words[r] = n2_word(low + R::LowMap::word_index(col, g*32+r, c.n));
        // Constant slots keep paired-nibble extraction as a word operation.
        dot_slot<0>(c.a, a_base + g*32, c.input_type, words, scale, zero, x, y);
        dot_slot<1>(c.a, a_base + g*32, c.input_type, words, scale, zero, x, y);
        dot_slot<2>(c.a, a_base + g*32, c.input_type, words, scale, zero, x, y);
        dot_slot<3>(c.a, a_base + g*32, c.input_type, words, scale, zero, x, y);
    }
    return make_float2((x[0]+x[1])+(x[2]+x[3]), (y[0]+y[1])+(y[2]+y[3]));
#endif
}

template<class Reader>
__device__ __forceinline__ float2 pair_dot(qkg_call_v1 const& c,int64_t a_base,
    uint16_t const* low,uint16_t const* high,uint8_t const* units,
    int col,int worker,int workers,int partition,int split) {
#if QKG_QTYPE == 12
    if (!(uintptr_t(low)&3) && !(uintptr_t(units)&15)) {
        if (c.input_type==0 && !((uintptr_t(c.a)+2*a_base)&3))
            return aligned_q4_pair_dot<Reader,0>(c,a_base,low,high,units,col,worker,workers,partition,split);
        if (c.input_type==1 && !((uintptr_t(c.a)+4*a_base)&15))
            return aligned_q4_pair_dot<Reader,1>(c,a_base,low,high,units,col,worker,workers,partition,split);
    }
#endif
    return fallback_q4_pair_dot<Reader>(c,a_base,low,high,units,col,worker,workers,partition,split);
}

template<int Columns, int Warps, bool Pair = false>
__global__ void kpack_gemv(qkg_call_v1 c, int split) {
    constexpr int Workers = Warps * 32 / Columns;
    int const tile=blockIdx.x, partition=blockIdx.y, row=blockIdx.z;
    int const col = (tile * Columns + threadIdx.x % Columns) * (Pair ? 2 : 1);
    int const worker = threadIdx.x / Columns;
    int const expert = expert_for(c, row);
    if (expert < 0 || expert >= c.experts) {
        if (threadIdx.x < Columns) {
            if (split == 1) c.output[int64_t(row) * c.out_row_stride + col] = __int_as_float(0x7fc00000);
            else static_cast<float*>(c.workspace)[(int64_t(row) * split + partition) * c.n + col]
                = __int_as_float(0x7fc00000);
        }
        if constexpr (Pair) if (threadIdx.x<Columns) {
            if (split==1) c.output[int64_t(row)*c.out_row_stride+col+1]=__int_as_float(0x7fc00000);
            else static_cast<float*>(c.workspace)[(int64_t(row)*split+partition)*c.n+col+1]=__int_as_float(0x7fc00000);
        }
        return;
    }
    int64_t const a_base = c.mode == QKG_INDEXED
        ? int64_t(row / c.topk) * c.a_token_stride + (row % c.topk % c.channels) * c.a_row_stride
        : int64_t(row) * c.a_row_stride;
    int64_t const nk = int64_t(c.n) * c.k;
    auto low = reinterpret_cast<uint16_t const*>(c.low + expert * (nk / 8 * R::lo_bits));
    uint16_t const* high = nullptr;
    if constexpr (R::hi_bits != 0)
        high = reinterpret_cast<uint16_t const*>(c.high + expert * (nk / 8 * R::hi_bits));
    auto units = c.units + expert * R::metadata_bytes(nk);
    float accum = 0.f, accum2 = 0.f;
    if constexpr (Pair) {
        auto dot=pair_dot<R>(c,a_base,low,high,units,col,worker,Workers,partition,split);
        accum=dot.x; accum2=dot.y;
    } else {
    for (int g = partition * Workers + worker; g < c.k / R::group; g += split * Workers) {
        auto const s = R::scale(units, col, g, c.n);
        // Eight b16 word addresses per group. Slots are K8-spaced in each
        // word, so the compiler reuses them across the short slot loop.
        #pragma unroll
        for (int r = 0; r < 8; ++r) {
            #pragma unroll
            for (int slot = 0; slot < R::group / 8; ++slot) {
                int const kk = g * R::group + r + 8 * slot;
                float a = c.input_type == QKG_F32
                    ? static_cast<float const*>(c.a)[a_base + kk]
                    : float(static_cast<Half const*>(c.a)[a_base + kk]);
                // The mixed-input GEMM boundary converts activations to FP16.
                a = float(Half(a));
                accum = fmaf(a, float(R::weight(R::code(low, high, col, kk, c.n), s)), accum);
            }
        }
    }
    }
    __shared__ float partial[Warps * 32 * (Pair ? 2 : 1)];
    partial[threadIdx.x] = accum;
    if constexpr (Pair) partial[Warps * 32 + threadIdx.x] = accum2;
    __syncthreads();
    if (threadIdx.x < Columns) {
        float value = 0.f;
        #pragma unroll
        for (int w = 0; w < Workers; ++w) value += partial[w * Columns + threadIdx.x];
        if (split == 1) c.output[int64_t(row) * c.out_row_stride + col] = value;
        else static_cast<float*>(c.workspace)[(int64_t(row) * split + partition) * c.n + col] = value;
        if constexpr (Pair) {
            float second=0.f;
            #pragma unroll
            for (int w=0;w<Workers;++w) second+=partial[Warps*32+w*Columns+threadIdx.x];
            if (split==1) c.output[int64_t(row)*c.out_row_stride+col+1]=second;
            else static_cast<float*>(c.workspace)[(int64_t(row)*split+partition)*c.n+col+1]=second;
        }
    }
}

__global__ void kpack_gemv_reduce(qkg_call_v1 c, int split) {
    for (int64_t i = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
         i < int64_t(c.rows) * c.n; i += int64_t(gridDim.x) * blockDim.x) {
        int64_t const row = i / c.n, col = i % c.n;
        float value = 0.f;
        for (int s = 0; s < split; ++s)
            value += static_cast<float const*>(c.workspace)[(row * split + s) * c.n + col];
        c.output[row * c.out_row_stride + col] = value;
    }
}

#if QKG_QTYPE == 12
// Four adjacent N columns per lane, one b64 read per K-pack word row.
// No byte/layout/arithmetic change: each output keeps the N2 FP32 dot order.
template<int Columns,int Warps,int Type>
__global__ void kpack_q4_n4_coop(qkg_call_v1 c,int split) {
    using namespace quactlize::dev::q4_native;
    constexpr int Workers=Warps*32/Columns;
    int const row=blockIdx.z,partition=blockIdx.y;
    int const tid=threadIdx.x,worker=tid/Columns;
    int const col=(blockIdx.x*Columns+tid%Columns)*4;
    int const expert=expert_for(c,row);
    if (expert<0 || expert>=c.experts) {
        if (tid<Columns) {
            auto dst=split==1 ? c.output+int64_t(row)*c.out_row_stride :
                static_cast<float*>(c.workspace)+(int64_t(row)*split+partition)*c.n;
            #pragma unroll
            for (int i=0;i<4;++i) dst[col+i]=__int_as_float(0x7fc00000);
        }
        return;
    }
    int64_t const a_base=c.mode==QKG_INDEXED
        ? int64_t(row/c.topk)*c.a_token_stride+(row%c.topk%c.channels)*c.a_row_stride
        : int64_t(row)*c.a_row_stride;
    auto low=reinterpret_cast<uint16_t const*>(c.low+int64_t(expert)*c.n*c.k/2);
    auto units=c.units+int64_t(expert)*c.n*(c.k/256)*16;
    float x[4]{},y[4]{},z[4]{},t[4]{};
    for (int g=partition*Workers+worker;g<c.k/32;g+=split*Workers) {
        auto p=units+(int64_t(g/8)*c.n+col)*16;
        auto s0=aligned_scale_zero(aligned_unit(p),g&7);
        auto s1=aligned_scale_zero(aligned_unit(p+16),g&7);
        auto s2=aligned_scale_zero(aligned_unit(p+32),g&7);
        auto s3=aligned_scale_zero(aligned_unit(p+48),g&7);
        __half2 scale0=__halves2half2(s0.scale,s1.scale),zero0=__halves2half2(s0.zero,s1.zero);
        __half2 scale1=__halves2half2(s2.scale,s3.scale),zero1=__halves2half2(s2.zero,s3.zero);
        uint32_t lo[8],hi[8];
        #pragma unroll
        for (int r=0;r<8;++r) {
            uint64_t word=*reinterpret_cast<uint64_t const*>(low+R::LowMap::word_index(col,g*32+r,c.n));
            lo[r]=uint32_t(word); hi[r]=uint32_t(word>>32);
        }
        #pragma unroll
        for (int slot=0;slot<4;++slot) {
            #pragma unroll
            for (int first=0;first<8;first+=4) {
                float4 a=aligned_activation<Type>(c.a,a_base+g*32+slot*8+first);
                float av[4]={a.x,a.y,a.z,a.w};
                #pragma unroll
                for (int i=0;i<4;++i) {
                    __half2 code0,code1;
                    if(slot==0) {code0=codes<0>(lo[first+i]);code1=codes<0>(hi[first+i]);}
                    else if(slot==1) {code0=codes<1>(lo[first+i]);code1=codes<1>(hi[first+i]);}
                    else if(slot==2) {code0=codes<2>(lo[first+i]);code1=codes<2>(hi[first+i]);}
                    else {code0=codes<3>(lo[first+i]);code1=codes<3>(hi[first+i]);}
                    float2 w0=__half22float2(__hfma2(code0,scale0,zero0));
                    float2 w1=__half22float2(__hfma2(code1,scale1,zero1));
                    x[i]=fmaf(av[i],w0.x,x[i]);y[i]=fmaf(av[i],w0.y,y[i]);
                    z[i]=fmaf(av[i],w1.x,z[i]);t[i]=fmaf(av[i],w1.y,t[i]);
                }
            }
        }
    }
    float v0=(x[0]+x[1])+(x[2]+x[3]);
    float v1=(y[0]+y[1])+(y[2]+y[3]);
    float v2=(z[0]+z[1])+(z[2]+z[3]);
    float v3=(t[0]+t[1])+(t[2]+t[3]);
    #pragma unroll
    for(int distance=Columns;distance<32;distance*=2) {
        v0+=__shfl_xor_sync(0xffffffffu,v0,distance);
        v1+=__shfl_xor_sync(0xffffffffu,v1,distance);
        v2+=__shfl_xor_sync(0xffffffffu,v2,distance);
        v3+=__shfl_xor_sync(0xffffffffu,v3,distance);
    }
    __shared__ float4 partial[Warps*Columns];
    if((tid&31)<Columns)
        partial[(tid/32)*Columns+(tid&31)]=make_float4(v0,v1,v2,v3);
    __syncthreads();
    if(tid<32) {
        float4 sum=make_float4(0,0,0,0);
        #pragma unroll
        for(int w=tid/Columns;w<Warps;w+=32/Columns) {
            float4 value=partial[w*Columns+tid%Columns];
            sum.x+=value.x;sum.y+=value.y;sum.z+=value.z;sum.w+=value.w;
        }
        #pragma unroll
        for(int distance=Columns;distance<32;distance*=2) {
            sum.x+=__shfl_xor_sync(0xffffffffu,sum.x,distance);
            sum.y+=__shfl_xor_sync(0xffffffffu,sum.y,distance);
            sum.z+=__shfl_xor_sync(0xffffffffu,sum.z,distance);
            sum.w+=__shfl_xor_sync(0xffffffffu,sum.w,distance);
        }
        if(tid<Columns) {
            auto dst=split==1 ? c.output+int64_t(row)*c.out_row_stride :
                static_cast<float*>(c.workspace)+(int64_t(row)*split+partition)*c.n;
            dst[col]=sum.x;dst[col+1]=sum.y;dst[col+2]=sum.z;dst[col+3]=sum.w;
        }
    }
}

template<int Columns,int Warps,int N,int K>
__global__ void kpack_q4_small_static(qkg_call_v1 c) {
    using namespace quactlize::dev::q4_native;
    constexpr int Type=0,split=1;
    constexpr int Workers=Warps*32/Columns;
    int const row=0,partition=0;
    int const tid=threadIdx.x,worker=tid/Columns;
    int const col=(blockIdx.x*Columns+tid%Columns)*4;
    constexpr int expert=0;
    constexpr int64_t a_base=0;
    auto low=reinterpret_cast<uint16_t const*>(c.low+int64_t(expert)*N*K/2);
    auto units=c.units+int64_t(expert)*N*(K/256)*16;
    float x[4]{},y[4]{},z[4]{},t[4]{};
    #pragma unroll
    for(int pass=0;pass<(K/32+Workers-1)/Workers;++pass) {
        int const g=pass*Workers+worker;
        if(g>=K/32) continue;
        auto p=units+(int64_t(g/8)*N+col)*16;
        auto s0=aligned_scale_zero(aligned_unit(p),g&7);
        auto s1=aligned_scale_zero(aligned_unit(p+16),g&7);
        auto s2=aligned_scale_zero(aligned_unit(p+32),g&7);
        auto s3=aligned_scale_zero(aligned_unit(p+48),g&7);
        __half2 scale0=__halves2half2(s0.scale,s1.scale),zero0=__halves2half2(s0.zero,s1.zero);
        __half2 scale1=__halves2half2(s2.scale,s3.scale),zero1=__halves2half2(s2.zero,s3.zero);
        uint32_t lo[8],hi[8];
        #pragma unroll
        for (int r=0;r<8;++r) {
            uint64_t word=*reinterpret_cast<uint64_t const*>(low+R::LowMap::word_index(col,g*32+r,N));
            lo[r]=uint32_t(word); hi[r]=uint32_t(word>>32);
        }
        #pragma unroll
        for (int slot=0;slot<4;++slot) {
            #pragma unroll
            for (int first=0;first<8;first+=4) {
                float4 a=aligned_activation<Type>(c.a,a_base+g*32+slot*8+first);
                float av[4]={a.x,a.y,a.z,a.w};
                #pragma unroll
                for (int i=0;i<4;++i) {
                    __half2 code0,code1;
                    if(slot==0) {code0=codes<0>(lo[first+i]);code1=codes<0>(hi[first+i]);}
                    else if(slot==1) {code0=codes<1>(lo[first+i]);code1=codes<1>(hi[first+i]);}
                    else if(slot==2) {code0=codes<2>(lo[first+i]);code1=codes<2>(hi[first+i]);}
                    else {code0=codes<3>(lo[first+i]);code1=codes<3>(hi[first+i]);}
                    float2 w0=__half22float2(__hfma2(code0,scale0,zero0));
                    float2 w1=__half22float2(__hfma2(code1,scale1,zero1));
                    x[i]=fmaf(av[i],w0.x,x[i]);y[i]=fmaf(av[i],w0.y,y[i]);
                    z[i]=fmaf(av[i],w1.x,z[i]);t[i]=fmaf(av[i],w1.y,t[i]);
                }
            }
        }
    }
    float v0=(x[0]+x[1])+(x[2]+x[3]);
    float v1=(y[0]+y[1])+(y[2]+y[3]);
    float v2=(z[0]+z[1])+(z[2]+z[3]);
    float v3=(t[0]+t[1])+(t[2]+t[3]);
    #pragma unroll
    for(int distance=Columns;distance<32;distance*=2) {
        v0+=__shfl_xor_sync(0xffffffffu,v0,distance);
        v1+=__shfl_xor_sync(0xffffffffu,v1,distance);
        v2+=__shfl_xor_sync(0xffffffffu,v2,distance);
        v3+=__shfl_xor_sync(0xffffffffu,v3,distance);
    }
    __shared__ float4 partial[Warps*Columns];
    if((tid&31)<Columns)
        partial[(tid/32)*Columns+(tid&31)]=make_float4(v0,v1,v2,v3);
    __syncthreads();
    if(tid<32) {
        float4 sum=make_float4(0,0,0,0);
        #pragma unroll
        for(int w=tid/Columns;w<Warps;w+=32/Columns) {
            float4 value=partial[w*Columns+tid%Columns];
            sum.x+=value.x;sum.y+=value.y;sum.z+=value.z;sum.w+=value.w;
        }
        #pragma unroll
        for(int distance=Columns;distance<32;distance*=2) {
            sum.x+=__shfl_xor_sync(0xffffffffu,sum.x,distance);
            sum.y+=__shfl_xor_sync(0xffffffffu,sum.y,distance);
            sum.z+=__shfl_xor_sync(0xffffffffu,sum.z,distance);
            sum.w+=__shfl_xor_sync(0xffffffffu,sum.w,distance);
        }
        if(tid<Columns) {
            auto dst=split==1 ? c.output+int64_t(row)*c.out_row_stride :
                static_cast<float*>(c.workspace)+(int64_t(row)*split+partition)*N;
            dst[col]=sum.x;dst[col+1]=sum.y;dst[col+2]=sum.z;dst[col+3]=sum.w;
        }
    }
}

template<int Columns,int Warps,int N,int K>
__global__ void kpack_q4_large_static(qkg_call_v1 c) {
    using namespace quactlize::dev::q4_native;
    constexpr int Type=0,split=1;
    constexpr int Workers=Warps*32/Columns;
    int const row=0,partition=0;
    int const tid=threadIdx.x,worker=tid/Columns;
    int const col=(blockIdx.x*Columns+tid%Columns)*4;
    constexpr int expert=0;
    constexpr int64_t a_base=0;
    auto low=reinterpret_cast<uint16_t const*>(c.low+int64_t(expert)*N*K/2);
    auto units=c.units+int64_t(expert)*N*(K/256)*16;
    float x[4]{},y[4]{},z[4]{},t[4]{};
    #pragma unroll
    for(int pass=0;pass<(K/32+Workers-1)/Workers;++pass) {
        int const g=pass*Workers+worker;
        if(g>=K/32) continue;
        auto p=units+(int64_t(g/8)*N+col)*16;
        auto s0=aligned_scale_zero(aligned_unit(p),g&7);
        auto s1=aligned_scale_zero(aligned_unit(p+16),g&7);
        auto s2=aligned_scale_zero(aligned_unit(p+32),g&7);
        auto s3=aligned_scale_zero(aligned_unit(p+48),g&7);
        __half2 scale0=__halves2half2(s0.scale,s1.scale),zero0=__halves2half2(s0.zero,s1.zero);
        __half2 scale1=__halves2half2(s2.scale,s3.scale),zero1=__halves2half2(s2.zero,s3.zero);
        uint32_t lo[8],hi[8];
        #pragma unroll
        for (int r=0;r<8;++r) {
            uint64_t word=*reinterpret_cast<uint64_t const*>(low+R::LowMap::word_index(col,g*32+r,N));
            lo[r]=uint32_t(word); hi[r]=uint32_t(word>>32);
        }
        #pragma unroll
        for (int slot=0;slot<4;++slot) {
            #pragma unroll
            for (int first=0;first<8;first+=4) {
                float4 a=aligned_activation<Type>(c.a,a_base+g*32+slot*8+first);
                float av[4]={a.x,a.y,a.z,a.w};
                #pragma unroll
                for (int i=0;i<4;++i) {
                    __half2 code0,code1;
                    if(slot==0) {code0=codes<0>(lo[first+i]);code1=codes<0>(hi[first+i]);}
                    else if(slot==1) {code0=codes<1>(lo[first+i]);code1=codes<1>(hi[first+i]);}
                    else if(slot==2) {code0=codes<2>(lo[first+i]);code1=codes<2>(hi[first+i]);}
                    else {code0=codes<3>(lo[first+i]);code1=codes<3>(hi[first+i]);}
                    float2 w0=__half22float2(__hfma2(code0,scale0,zero0));
                    float2 w1=__half22float2(__hfma2(code1,scale1,zero1));
                    x[i]=fmaf(av[i],w0.x,x[i]);y[i]=fmaf(av[i],w0.y,y[i]);
                    z[i]=fmaf(av[i],w1.x,z[i]);t[i]=fmaf(av[i],w1.y,t[i]);
                }
            }
        }
    }
    float v0=(x[0]+x[1])+(x[2]+x[3]);
    float v1=(y[0]+y[1])+(y[2]+y[3]);
    float v2=(z[0]+z[1])+(z[2]+z[3]);
    float v3=(t[0]+t[1])+(t[2]+t[3]);
    #pragma unroll
    for(int distance=Columns;distance<32;distance*=2) {
        v0+=__shfl_xor_sync(0xffffffffu,v0,distance);
        v1+=__shfl_xor_sync(0xffffffffu,v1,distance);
        v2+=__shfl_xor_sync(0xffffffffu,v2,distance);
        v3+=__shfl_xor_sync(0xffffffffu,v3,distance);
    }
    __shared__ float4 partial[Warps*Columns];
    if((tid&31)<Columns)
        partial[(tid/32)*Columns+(tid&31)]=make_float4(v0,v1,v2,v3);
    __syncthreads();
    if(tid<32) {
        float4 sum=make_float4(0,0,0,0);
        #pragma unroll
        for(int w=tid/Columns;w<Warps;w+=32/Columns) {
            float4 value=partial[w*Columns+tid%Columns];
            sum.x+=value.x;sum.y+=value.y;sum.z+=value.z;sum.w+=value.w;
        }
        #pragma unroll
        for(int distance=Columns;distance<32;distance*=2) {
            sum.x+=__shfl_xor_sync(0xffffffffu,sum.x,distance);
            sum.y+=__shfl_xor_sync(0xffffffffu,sum.y,distance);
            sum.z+=__shfl_xor_sync(0xffffffffu,sum.z,distance);
            sum.w+=__shfl_xor_sync(0xffffffffu,sum.w,distance);
        }
        if(tid<Columns) {
            auto dst=split==1 ? c.output+int64_t(row)*c.out_row_stride :
                static_cast<float*>(c.workspace)+(int64_t(row)*split+partition)*N;
            dst[col]=sum.x;dst[col+1]=sum.y;dst[col+2]=sum.z;dst[col+3]=sum.w;
        }
    }
}

#endif
// Distinct numerical contract: FP16 A, exact integer codes and FP32 grouped
// affine. No per-weight FP16 rounding or expanded workspace. This computes
// sum_g (d*s_g * dot(q_g,A_g) - dmin*m_g * sum(A_g)) in FP32.
// It is compared independently with original GGUF, not called FP16-weight GEMV.
__device__ __forceinline__ float2 q4_affine_header(uint4 u,unsigned group) {
    uint64_t run=(group&4) ? uint64_t(u.z>>16)|(uint64_t(u.w)<<16)
                          : uint64_t(u.y)|(uint64_t(u.z&0xffff)<<32);
    unsigned shift=6*(group&3);
    float sc=float(unsigned(run>>shift)&63),mn=float(unsigned(run>>(24+shift))&63);
    return make_float2(__half2float(__ushort_as_half(uint16_t(u.x)))*sc,
                      -__half2float(__ushort_as_half(uint16_t(u.x>>16)))*mn);
}

template<int Columns,int Warps,int P,int N,int K,bool Early>
__global__ void q4_group_affine(void const* a_ptr,uint8_t const* low_ptr,uint8_t const* units_ptr,float* out_ptr) {
    using namespace quactlize::dev::q4_native;
    constexpr int Workers=Warps*32/Columns,Pairs=P/2;
    int const tid=threadIdx.x,worker=tid/Columns,col=blockIdx.x*(Columns*P)+(tid%Columns)*P;
    auto low=reinterpret_cast<uint16_t const*>(low_ptr);
    float2 total[Pairs]{};
    #pragma unroll
    for(int pass=0;pass<(K/32+Workers-1)/Workers;++pass) {
        int const g=pass*Workers+worker;
        if(g>=K/32) continue;
        uint4 metadata[Early ? P : 1];
        if constexpr(Early) {
            #pragma unroll
            for(int p=0;p<P;++p) metadata[p]=aligned_unit(units_ptr+(size_t(g/8)*N+col+p)*16);
        }
        float2 dot[Pairs]{};
        float a_sum=0;
        #pragma unroll
        for(int half=0;half<2;++half) {
            uint32_t words[4][Pairs];
            #pragma unroll
            for(int r=0;r<4;++r) {
                auto ptr=low+size_t(g*8+half*4+r)*N+col;
                if constexpr(P==2) words[r][0]=*reinterpret_cast<uint32_t const*>(ptr);
                else if constexpr(P==4) {
                    uint2 v=*reinterpret_cast<uint2 const*>(ptr);words[r][0]=v.x;words[r][1]=v.y;
                } else {
                    uint4 v=*reinterpret_cast<uint4 const*>(ptr);
                    words[r][0]=v.x;words[r][1]=v.y;words[r][2]=v.z;words[r][3]=v.w;
                }
            }
            #pragma unroll
            for(int slot=0;slot<4;++slot) {
                float4 av=aligned_activation<0>(a_ptr,g*32+slot*8+half*4);
                float ax[4]={av.x,av.y,av.z,av.w};
                a_sum+=(av.x+av.y)+(av.z+av.w);
                #pragma unroll
                for(int r=0;r<4;++r) {
                    #pragma unroll
                    for(int p=0;p<Pairs;++p) {
                        __half2 q;
                        if(slot==0) q=codes<0>(words[r][p]);
                        else if(slot==1) q=codes<1>(words[r][p]);
                        else if(slot==2) q=codes<2>(words[r][p]);
                        else q=codes<3>(words[r][p]);
                        float2 v=__half22float2(q);
                        dot[p].x=fmaf(ax[r],v.x,dot[p].x);
                        dot[p].y=fmaf(ax[r],v.y,dot[p].y);
                    }
                }
            }
        }
        #pragma unroll
        for(int p=0;p<Pairs;++p) {
            uint4 u0,u1;
            if constexpr(Early) {u0=metadata[2*p];u1=metadata[2*p+1];}
            else {
                u0=aligned_unit(units_ptr+(size_t(g/8)*N+col+2*p)*16);
                u1=aligned_unit(units_ptr+(size_t(g/8)*N+col+2*p+1)*16);
            }
            float2 s0=q4_affine_header(u0,g&7),s1=q4_affine_header(u1,g&7);
            total[p].x+=fmaf(s0.x,dot[p].x,s0.y*a_sum);
            total[p].y+=fmaf(s1.x,dot[p].y,s1.y*a_sum);
        }
    }
    constexpr int TileN=Columns*P;
    static_assert(TileN<=32);
    float values[P];
    #pragma unroll
    for(int p=0;p<Pairs;++p) {values[2*p]=total[p].x;values[2*p+1]=total[p].y;}
    int const lane=tid%32;
    float value=q4_reduce_scatter_steps<P,Columns>(values,lane);
    __shared__ float partial[Warps*TileN];
    if(lane<TileN) partial[(tid/32)*TileN+(lane%Columns)*P+lane/Columns]=value;
    __syncthreads();
    if(tid<32) {
        float sum=0;
        #pragma unroll
        for(int w=tid/TileN;w<Warps;w+=32/TileN) sum+=partial[w*TileN+tid%TileN];
        #pragma unroll
        for(int d=TileN;d<32;d*=2) sum+=__shfl_xor_sync(0xffffffffu,sum,d);
        if(tid<TileN) out_ptr[blockIdx.x*TileN+tid]=sum;
    }
}

template<int Columns, int Warps, bool Pair = false> int launch(qkg_call_v1 const& c, int split) {
    auto stream = static_cast<hggcStream_t>(c.stream);
    if (c.rows>65535) return QKG_INVALID;
    dim3 const grid(c.n/(Columns*(Pair ? 2 : 1)),split,c.rows);
#if QKG_QTYPE == 12
    bool const aligned_b=!(uintptr_t(c.low)&7) && !(uintptr_t(c.units)&15);
    bool const aligned_a=c.input_type==0
        ? !(uintptr_t(c.a)&3) && !(c.a_row_stride&1) && !(c.a_token_stride&1)
        : !(uintptr_t(c.a)&15) && !(c.a_row_stride&3) && !(c.a_token_stride&3);
    if (Pair && aligned_b && aligned_a) {
        dim3 const n4_grid(c.n/(Columns*4),split,c.rows);
        if(c.input_type==0 && c.mode==QKG_DENSE && c.rows==1 && split==1) {
            if(c.n==512 && c.k==2048) {
                kpack_q4_small_static<Columns,Warps,512,2048><<<n4_grid,Warps*32,0,stream>>>(c);
                return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
            }
            if(c.n==1024 && c.k==5120) {
                kpack_q4_small_static<Columns,Warps,1024,5120><<<n4_grid,Warps*32,0,stream>>>(c);
                return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
            }
        }
        // Limit full-loop specialization to the useful warm-cache N tile
        // sizes. Other recipes, inputs, shapes and split counts remain generic.
        if constexpr ((Columns==4 || Columns==8) && Warps>=4) {
            if(c.input_type==0 && c.mode==QKG_DENSE && c.rows==1 && split==1) {
                if(c.n==4096 && c.k==2048) {
                    kpack_q4_large_static<Columns,Warps,4096,2048><<<n4_grid,Warps*32,0,stream>>>(c);
                    return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
                }
                if(c.n==4096 && c.k==4096) {
                    kpack_q4_large_static<Columns,Warps,4096,4096><<<n4_grid,Warps*32,0,stream>>>(c);
                    return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
                }
                if(c.n==5120 && c.k==8192) {
                    kpack_q4_large_static<Columns,Warps,5120,8192><<<n4_grid,Warps*32,0,stream>>>(c);
                    return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
                }
                if(c.n==8192 && c.k==5120) {
                    kpack_q4_large_static<Columns,Warps,8192,5120><<<n4_grid,Warps*32,0,stream>>>(c);
                    return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
                }
            }
        }
        if(c.input_type==0) kpack_q4_n4_coop<Columns,Warps,0><<<n4_grid,Warps*32,0,stream>>>(c,split);
        else kpack_q4_n4_coop<Columns,Warps,1><<<n4_grid,Warps*32,0,stream>>>(c,split);
    } else
#endif
    kpack_gemv<Columns,Warps,Pair><<<grid,Warps*32,0,stream>>>(c,split);
    if (hggcGetLastError() != hggcSuccess) return QKG_RUNTIME;
    if (split > 1) {
        uint64_t const count = (uint64_t(c.rows)*c.n+255)/256;
        kpack_gemv_reduce<<<unsigned(count < 65535 ? count : 65535),256,0,stream>>>(c,split);
    }
    return hggcGetLastError() == hggcSuccess ? QKG_OK : QKG_RUNTIME;
}
}

extern "C" int qkg_launch_12(qkg_call_v1 const&,qkg_config_v1 const&) {return QKG_INVALID;}
extern "C" int qkg_pair_launch_12(qkg_call_v1 const& c,qkg_config_v1 const& f) {
    using namespace QKG_CONCAT(kpack_q,QKG_QTYPE);
    if(c.mode!=QKG_DENSE || c.rows!=1 || c.experts!=1 || c.input_type!=QKG_F16 || f.split!=1 ||
       (uintptr_t(c.a)&15) || (uintptr_t(c.low)&15) || (uintptr_t(c.units)&15)) return QKG_INVALID;
    if(hggcGetLastError()!=hggcSuccess) return QKG_RUNTIME;
    if(f.columns==1 && f.warps==2 && c.n==512 && c.k==2048) {
        q4_group_affine<1,2,8,512,2048,true><<<c.n/8,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==2 && c.n==1024 && c.k==5120) {
        q4_group_affine<1,2,8,1024,5120,true><<<c.n/8,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==2 && c.n==4096 && c.k==2048) {
        q4_group_affine<1,2,8,4096,2048,true><<<c.n/8,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==2 && c.n==4096 && c.k==4096) {
        q4_group_affine<1,2,8,4096,4096,true><<<c.n/8,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==2 && c.n==5120 && c.k==8192) {
        q4_group_affine<1,2,8,5120,8192,true><<<c.n/8,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==2 && c.n==8192 && c.k==5120) {
        q4_group_affine<1,2,8,8192,5120,true><<<c.n/8,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==4 && c.n==512 && c.k==2048) {
        q4_group_affine<1,4,8,512,2048,true><<<c.n/8,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==4 && c.n==1024 && c.k==5120) {
        q4_group_affine<1,4,8,1024,5120,true><<<c.n/8,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==4 && c.n==4096 && c.k==2048) {
        q4_group_affine<1,4,8,4096,2048,true><<<c.n/8,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==4 && c.n==4096 && c.k==4096) {
        q4_group_affine<1,4,8,4096,4096,true><<<c.n/8,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==4 && c.n==5120 && c.k==8192) {
        q4_group_affine<1,4,8,5120,8192,true><<<c.n/8,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==4 && c.n==8192 && c.k==5120) {
        q4_group_affine<1,4,8,8192,5120,true><<<c.n/8,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==5 && c.n==512 && c.k==2048) {
        q4_group_affine<1,5,8,512,2048,true><<<c.n/8,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==5 && c.n==1024 && c.k==5120) {
        q4_group_affine<1,5,8,1024,5120,true><<<c.n/8,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==5 && c.n==4096 && c.k==2048) {
        q4_group_affine<1,5,8,4096,2048,true><<<c.n/8,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==5 && c.n==4096 && c.k==4096) {
        q4_group_affine<1,5,8,4096,4096,true><<<c.n/8,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==5 && c.n==5120 && c.k==8192) {
        q4_group_affine<1,5,8,5120,8192,true><<<c.n/8,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==5 && c.n==8192 && c.k==5120) {
        q4_group_affine<1,5,8,8192,5120,true><<<c.n/8,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==8 && c.n==512 && c.k==2048) {
        q4_group_affine<1,8,8,512,2048,true><<<c.n/8,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==8 && c.n==1024 && c.k==5120) {
        q4_group_affine<1,8,8,1024,5120,true><<<c.n/8,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==8 && c.n==4096 && c.k==2048) {
        q4_group_affine<1,8,8,4096,2048,true><<<c.n/8,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==8 && c.n==4096 && c.k==4096) {
        q4_group_affine<1,8,8,4096,4096,true><<<c.n/8,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==8 && c.n==5120 && c.k==8192) {
        q4_group_affine<1,8,8,5120,8192,true><<<c.n/8,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==8 && c.n==8192 && c.k==5120) {
        q4_group_affine<1,8,8,8192,5120,true><<<c.n/8,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==10 && c.n==512 && c.k==2048) {
        q4_group_affine<1,10,8,512,2048,true><<<c.n/8,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==10 && c.n==1024 && c.k==5120) {
        q4_group_affine<1,10,8,1024,5120,true><<<c.n/8,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==10 && c.n==4096 && c.k==2048) {
        q4_group_affine<1,10,8,4096,2048,true><<<c.n/8,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==10 && c.n==4096 && c.k==4096) {
        q4_group_affine<1,10,8,4096,4096,true><<<c.n/8,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==10 && c.n==5120 && c.k==8192) {
        q4_group_affine<1,10,8,5120,8192,true><<<c.n/8,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==10 && c.n==8192 && c.k==5120) {
        q4_group_affine<1,10,8,8192,5120,true><<<c.n/8,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==16 && c.n==512 && c.k==2048) {
        q4_group_affine<1,16,8,512,2048,true><<<c.n/8,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==16 && c.n==1024 && c.k==5120) {
        q4_group_affine<1,16,8,1024,5120,true><<<c.n/8,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==16 && c.n==4096 && c.k==2048) {
        q4_group_affine<1,16,8,4096,2048,true><<<c.n/8,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==16 && c.n==4096 && c.k==4096) {
        q4_group_affine<1,16,8,4096,4096,true><<<c.n/8,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==16 && c.n==5120 && c.k==8192) {
        q4_group_affine<1,16,8,5120,8192,true><<<c.n/8,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==1 && f.warps==16 && c.n==8192 && c.k==5120) {
        q4_group_affine<1,16,8,8192,5120,true><<<c.n/8,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==2 && c.n==512 && c.k==2048) {
        q4_group_affine<2,2,8,512,2048,true><<<c.n/16,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==2 && c.n==1024 && c.k==5120) {
        q4_group_affine<2,2,8,1024,5120,true><<<c.n/16,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==2 && c.n==4096 && c.k==2048) {
        q4_group_affine<2,2,8,4096,2048,true><<<c.n/16,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==2 && c.n==4096 && c.k==4096) {
        q4_group_affine<2,2,8,4096,4096,true><<<c.n/16,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==2 && c.n==5120 && c.k==8192) {
        q4_group_affine<2,2,8,5120,8192,true><<<c.n/16,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==2 && c.n==8192 && c.k==5120) {
        q4_group_affine<2,2,8,8192,5120,true><<<c.n/16,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==4 && c.n==512 && c.k==2048) {
        q4_group_affine<2,4,8,512,2048,true><<<c.n/16,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==4 && c.n==1024 && c.k==5120) {
        q4_group_affine<2,4,8,1024,5120,true><<<c.n/16,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==4 && c.n==4096 && c.k==2048) {
        q4_group_affine<2,4,8,4096,2048,true><<<c.n/16,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==4 && c.n==4096 && c.k==4096) {
        q4_group_affine<2,4,8,4096,4096,true><<<c.n/16,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==4 && c.n==5120 && c.k==8192) {
        q4_group_affine<2,4,8,5120,8192,true><<<c.n/16,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==4 && c.n==8192 && c.k==5120) {
        q4_group_affine<2,4,8,8192,5120,true><<<c.n/16,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==5 && c.n==512 && c.k==2048) {
        q4_group_affine<2,5,8,512,2048,true><<<c.n/16,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==5 && c.n==1024 && c.k==5120) {
        q4_group_affine<2,5,8,1024,5120,true><<<c.n/16,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==5 && c.n==4096 && c.k==2048) {
        q4_group_affine<2,5,8,4096,2048,true><<<c.n/16,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==5 && c.n==4096 && c.k==4096) {
        q4_group_affine<2,5,8,4096,4096,true><<<c.n/16,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==5 && c.n==5120 && c.k==8192) {
        q4_group_affine<2,5,8,5120,8192,true><<<c.n/16,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==5 && c.n==8192 && c.k==5120) {
        q4_group_affine<2,5,8,8192,5120,true><<<c.n/16,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==8 && c.n==512 && c.k==2048) {
        q4_group_affine<2,8,8,512,2048,true><<<c.n/16,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==8 && c.n==1024 && c.k==5120) {
        q4_group_affine<2,8,8,1024,5120,true><<<c.n/16,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==8 && c.n==4096 && c.k==2048) {
        q4_group_affine<2,8,8,4096,2048,true><<<c.n/16,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==8 && c.n==4096 && c.k==4096) {
        q4_group_affine<2,8,8,4096,4096,true><<<c.n/16,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==8 && c.n==5120 && c.k==8192) {
        q4_group_affine<2,8,8,5120,8192,true><<<c.n/16,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==8 && c.n==8192 && c.k==5120) {
        q4_group_affine<2,8,8,8192,5120,true><<<c.n/16,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==10 && c.n==512 && c.k==2048) {
        q4_group_affine<2,10,8,512,2048,true><<<c.n/16,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==10 && c.n==1024 && c.k==5120) {
        q4_group_affine<2,10,8,1024,5120,true><<<c.n/16,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==10 && c.n==4096 && c.k==2048) {
        q4_group_affine<2,10,8,4096,2048,true><<<c.n/16,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==10 && c.n==4096 && c.k==4096) {
        q4_group_affine<2,10,8,4096,4096,true><<<c.n/16,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==10 && c.n==5120 && c.k==8192) {
        q4_group_affine<2,10,8,5120,8192,true><<<c.n/16,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==10 && c.n==8192 && c.k==5120) {
        q4_group_affine<2,10,8,8192,5120,true><<<c.n/16,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==16 && c.n==512 && c.k==2048) {
        q4_group_affine<2,16,8,512,2048,true><<<c.n/16,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==16 && c.n==1024 && c.k==5120) {
        q4_group_affine<2,16,8,1024,5120,true><<<c.n/16,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==16 && c.n==4096 && c.k==2048) {
        q4_group_affine<2,16,8,4096,2048,true><<<c.n/16,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==16 && c.n==4096 && c.k==4096) {
        q4_group_affine<2,16,8,4096,4096,true><<<c.n/16,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==16 && c.n==5120 && c.k==8192) {
        q4_group_affine<2,16,8,5120,8192,true><<<c.n/16,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==2 && f.warps==16 && c.n==8192 && c.k==5120) {
        q4_group_affine<2,16,8,8192,5120,true><<<c.n/16,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==2 && c.n==512 && c.k==2048) {
        q4_group_affine<4,2,8,512,2048,true><<<c.n/32,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==2 && c.n==1024 && c.k==5120) {
        q4_group_affine<4,2,8,1024,5120,true><<<c.n/32,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==2 && c.n==4096 && c.k==2048) {
        q4_group_affine<4,2,8,4096,2048,true><<<c.n/32,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==2 && c.n==4096 && c.k==4096) {
        q4_group_affine<4,2,8,4096,4096,true><<<c.n/32,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==2 && c.n==5120 && c.k==8192) {
        q4_group_affine<4,2,8,5120,8192,true><<<c.n/32,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==2 && c.n==8192 && c.k==5120) {
        q4_group_affine<4,2,8,8192,5120,true><<<c.n/32,64,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==4 && c.n==512 && c.k==2048) {
        q4_group_affine<4,4,8,512,2048,true><<<c.n/32,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==4 && c.n==1024 && c.k==5120) {
        q4_group_affine<4,4,8,1024,5120,true><<<c.n/32,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==4 && c.n==4096 && c.k==2048) {
        q4_group_affine<4,4,8,4096,2048,true><<<c.n/32,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==4 && c.n==4096 && c.k==4096) {
        q4_group_affine<4,4,8,4096,4096,true><<<c.n/32,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==4 && c.n==5120 && c.k==8192) {
        q4_group_affine<4,4,8,5120,8192,true><<<c.n/32,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==4 && c.n==8192 && c.k==5120) {
        q4_group_affine<4,4,8,8192,5120,true><<<c.n/32,128,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==5 && c.n==512 && c.k==2048) {
        q4_group_affine<4,5,8,512,2048,true><<<c.n/32,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==5 && c.n==1024 && c.k==5120) {
        q4_group_affine<4,5,8,1024,5120,true><<<c.n/32,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==5 && c.n==4096 && c.k==2048) {
        q4_group_affine<4,5,8,4096,2048,true><<<c.n/32,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==5 && c.n==4096 && c.k==4096) {
        q4_group_affine<4,5,8,4096,4096,true><<<c.n/32,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==5 && c.n==5120 && c.k==8192) {
        q4_group_affine<4,5,8,5120,8192,true><<<c.n/32,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==5 && c.n==8192 && c.k==5120) {
        q4_group_affine<4,5,8,8192,5120,true><<<c.n/32,160,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==8 && c.n==512 && c.k==2048) {
        q4_group_affine<4,8,8,512,2048,true><<<c.n/32,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==8 && c.n==1024 && c.k==5120) {
        q4_group_affine<4,8,8,1024,5120,true><<<c.n/32,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==8 && c.n==4096 && c.k==2048) {
        q4_group_affine<4,8,8,4096,2048,true><<<c.n/32,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==8 && c.n==4096 && c.k==4096) {
        q4_group_affine<4,8,8,4096,4096,true><<<c.n/32,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==8 && c.n==5120 && c.k==8192) {
        q4_group_affine<4,8,8,5120,8192,true><<<c.n/32,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==8 && c.n==8192 && c.k==5120) {
        q4_group_affine<4,8,8,8192,5120,true><<<c.n/32,256,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==10 && c.n==512 && c.k==2048) {
        q4_group_affine<4,10,8,512,2048,true><<<c.n/32,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==10 && c.n==1024 && c.k==5120) {
        q4_group_affine<4,10,8,1024,5120,true><<<c.n/32,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==10 && c.n==4096 && c.k==2048) {
        q4_group_affine<4,10,8,4096,2048,true><<<c.n/32,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==10 && c.n==4096 && c.k==4096) {
        q4_group_affine<4,10,8,4096,4096,true><<<c.n/32,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==10 && c.n==5120 && c.k==8192) {
        q4_group_affine<4,10,8,5120,8192,true><<<c.n/32,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==10 && c.n==8192 && c.k==5120) {
        q4_group_affine<4,10,8,8192,5120,true><<<c.n/32,320,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==16 && c.n==512 && c.k==2048) {
        q4_group_affine<4,16,8,512,2048,true><<<c.n/32,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==16 && c.n==1024 && c.k==5120) {
        q4_group_affine<4,16,8,1024,5120,true><<<c.n/32,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==16 && c.n==4096 && c.k==2048) {
        q4_group_affine<4,16,8,4096,2048,true><<<c.n/32,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==16 && c.n==4096 && c.k==4096) {
        q4_group_affine<4,16,8,4096,4096,true><<<c.n/32,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==16 && c.n==5120 && c.k==8192) {
        q4_group_affine<4,16,8,5120,8192,true><<<c.n/32,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    if(f.columns==4 && f.warps==16 && c.n==8192 && c.k==5120) {
        q4_group_affine<4,16,8,8192,5120,true><<<c.n/32,512,0,static_cast<hggcStream_t>(c.stream)>>>(c.a,c.low,c.units,c.output);
        return hggcGetLastError()==hggcSuccess ? QKG_OK : QKG_RUNTIME;
    }
    return QKG_INVALID;
}
