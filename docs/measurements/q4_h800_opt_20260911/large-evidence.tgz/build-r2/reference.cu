#include "gemv_ref_fp32.cuh"
#include "bload_contract.hpp"
extern "C" int q4_ref_fp32_run(int c, int w, int n, int k,
        void const* a, void const* raw, void* out, void* stream) {
    if (!q4_bload::shape(n,k) || w!=8 || (c!=1 && c!=2 && c!=4)) return -1;
    if (!a || !raw || !out || (uintptr_t(a)&15) || (uintptr_t(raw)&15) || (uintptr_t(out)&3)) return -2;
#define RAW_ARM(C) if (c==C) { q4k_gemv_fp32::launch_q4k_gemv<C,8,1>( \
    static_cast<half const*>(a),static_cast<q4k_gemv_fp32::block_q4_K const*>(raw), \
    static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream)); return int(cudaGetLastError()); }
    RAW_ARM(1)
    RAW_ARM(2)
    RAW_ARM(4)
#undef RAW_ARM
    return -1;
}
