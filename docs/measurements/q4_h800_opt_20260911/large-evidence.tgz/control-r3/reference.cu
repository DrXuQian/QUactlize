#include "gemv_ref_fp32.cuh"
#include "bload_contract.hpp"
extern "C" int q4_ref_fp32_run_v2(int c,int w,int kw, int n,int k,void const* a,void const* raw,void* out,void* stream) {
    if(!q4_bload::shape(n,k) || !a || !raw || !out || (uintptr_t(a)&15) || (uintptr_t(raw)&15) || (uintptr_t(out)&3)) return -1;
    if(c==1 && w==1 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<1,1,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==1 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<1,1,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==1 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<1,1,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==1 && kw==8) {
        q4k_gemv_fp32::launch_q4k_gemv<1,1,8>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==2 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<1,2,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==2 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<1,2,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==2 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<1,2,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==2 && kw==8) {
        q4k_gemv_fp32::launch_q4k_gemv<1,2,8>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==4 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<1,4,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==4 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<1,4,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==4 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<1,4,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==4 && kw==8) {
        q4k_gemv_fp32::launch_q4k_gemv<1,4,8>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==8 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<1,8,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==8 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<1,8,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==1 && w==8 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<1,8,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==1 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<2,1,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==1 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<2,1,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==1 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<2,1,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==1 && kw==8) {
        q4k_gemv_fp32::launch_q4k_gemv<2,1,8>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==2 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<2,2,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==2 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<2,2,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==2 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<2,2,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==2 && kw==8) {
        q4k_gemv_fp32::launch_q4k_gemv<2,2,8>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==4 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<2,4,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==4 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<2,4,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==4 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<2,4,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==4 && kw==8) {
        q4k_gemv_fp32::launch_q4k_gemv<2,4,8>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==8 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<2,8,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==8 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<2,8,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==2 && w==8 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<2,8,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==1 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<4,1,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==1 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<4,1,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==1 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<4,1,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==1 && kw==8) {
        q4k_gemv_fp32::launch_q4k_gemv<4,1,8>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==2 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<4,2,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==2 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<4,2,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==2 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<4,2,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==2 && kw==8) {
        q4k_gemv_fp32::launch_q4k_gemv<4,2,8>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==4 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<4,4,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==4 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<4,4,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==4 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<4,4,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==4 && kw==8) {
        q4k_gemv_fp32::launch_q4k_gemv<4,4,8>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==8 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<4,8,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==8 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<4,8,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==4 && w==8 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<4,8,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==1 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<8,1,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==1 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<8,1,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==1 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<8,1,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==1 && kw==8) {
        q4k_gemv_fp32::launch_q4k_gemv<8,1,8>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==2 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<8,2,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==2 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<8,2,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==2 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<8,2,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==2 && kw==8) {
        q4k_gemv_fp32::launch_q4k_gemv<8,2,8>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==4 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<8,4,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==4 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<8,4,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==4 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<8,4,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==4 && kw==8) {
        q4k_gemv_fp32::launch_q4k_gemv<8,4,8>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==8 && kw==1) {
        q4k_gemv_fp32::launch_q4k_gemv<8,8,1>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==8 && kw==2) {
        q4k_gemv_fp32::launch_q4k_gemv<8,8,2>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    if(c==8 && w==8 && kw==4) {
        q4k_gemv_fp32::launch_q4k_gemv<8,8,4>(static_cast<half const*>(a),
            static_cast<q4k_gemv_fp32::block_q4_K const*>(raw),static_cast<float*>(out),1,n,k,static_cast<cudaStream_t>(stream));
        return int(cudaGetLastError());
    }
    return -1;
}
